package mainModules;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class Luma_AddToCart {

	Select s;
	
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void newuser(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Create an")).click();
		driver.findElement(By.id("firstname")).sendKeys("Puja");
		//Thread.sleep(2000);
		driver.findElement(By.id("lastname")).sendKeys("Kumari");
		//Thread.sleep(2000);
		driver.findElement(By.id("email_address")).sendKeys("kumaripuja2359@gmail.com");
		//Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Family@143");
		//Thread.sleep(2000);
		driver.findElement(By.id("password-confirmation")).sendKeys("Family@143");
	//	Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Create an")).click();
	}
public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("kumaripuja2359@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Family@143");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
	}
public void searchhere(WebDriver driver, String search) throws InterruptedException 
  {
	String searchhere= JOptionPane.showInputDialog("Search Here");
	driver.findElement(By.id("search")).sendKeys(searchhere);
	driver.findElement(By.xpath("//button[@aria-label='Search']")).click();	
	//driver.findElement(By.partialLinkText("tops and tees")).click();
	Thread.sleep(2000);
	driver.findElement(By.id("option-label-size-143-item-170")).click();  	
	Thread.sleep(2000);
	driver.findElement(By.id("option-label-color-93-item-57")).click();
	}
public void AddToCart(WebDriver driver) throws InterruptedException
{
	driver.findElement(By.xpath("//div[@class='products wrapper grid products-grid']//div[3]//div[1]//div[1]//form[1]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[@class='action showcart']")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//a[@class='action edit']")).click();
	Thread.sleep(2000);
	driver.findElement(By.id("option-label-size-143-item-168")).click();  	
	Thread.sleep(2000);
	driver.findElement(By.id("option-label-color-93-item-56")).click();
	Thread.sleep(2000);
	//driver.findElement(By.id("qty")).sendKeys("2");
	Thread.sleep(2000);
	driver.findElement(By.id("product-updatecart-button")).click();
}
public void summary(WebDriver driver) throws InterruptedException
{
	
	driver.findElement(By.xpath("//strong[@id='block-shipping-heading']")).click();
	 s = new Select(driver.findElement(By.xpath("//select[@name='country_id']")));
	 Thread.sleep(2000);
	 s.selectByVisibleText("India");
	 Thread.sleep(2000);
	 s = new Select(driver.findElement(By.xpath("//select[@name='region_id']")));
     s.selectByIndex(16);
   //  String zipcode= JOptionPane.showInputDialog("Zip/Postal Code");
     driver.findElement(By.xpath("//input[@name='postcode']")).sendKeys(" ");
     driver.findElement(By.xpath("//button[@data-role='proceed-to-checkout']")).click();
     Thread.sleep(5000);
     driver.findElement(By.xpath("//span[text()='Next']")).click();
}
public void ReviewAndPayments(WebDriver driver) throws InterruptedException 
{
	driver.findElement(By.xpath("//span[text()='Place Order']")).click();		
	Thread.sleep(2000);
	//driver.findElement(By.xpath("//a[@class='order-number']")).click();
	//driver.findElement(By.xpath("//a[@class='action primary continue']")).click();
}
	public static void main(String[] args) throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\msedgedriver.exe");
        WebDriver driver =new EdgeDriver();
        
        Luma_AddToCart l= new  Luma_AddToCart();
        
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.newuser(driver);
        Thread.sleep(2000);
        l.signin(driver);
        l.searchhere(driver, "Tops" );
    	Thread.sleep(2000);
        l.AddToCart(driver);
    	Thread.sleep(2000);
    	l.summary(driver);
    	Thread.sleep(2000);
    //	l.ShippingAddress(driver);
    	Thread.sleep(2000);
    	l.ReviewAndPayments(driver);

	}

}
